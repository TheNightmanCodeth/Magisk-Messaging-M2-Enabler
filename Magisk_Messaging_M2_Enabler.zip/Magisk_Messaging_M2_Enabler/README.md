## Description
This module enables the new Material2 UI in android Messages app. This is accomplished by modifying two lines in the shared_prefs of the messaging app on boot-up.

#### Current Version
1.0.0

#### Changelog

* 1.0.0 Initial release

#### Magisk Template
v1500

#### NOTICE

* You should use latest Magisk Manager to install this module. If you meet any problem under installation from Magisk Manager, please try to install it from recovery.